package com.sync.poc.exchange.rates.transform;

import com.sync.poc.exchange.rates.domain.ExchangeRatesInfo;
import com.sync.poc.exchange.rates.model.ExchangeRates;
import com.sync.poc.exchange.rates.model.Rates;

public class ExchangeRatesTransform {

	public static ExchangeRatesInfo getExchangeRatesInfo(ExchangeRates exRates) {
		ExchangeRatesInfo exInfo = new ExchangeRatesInfo();
		exInfo.setBase(exRates.getBase());
		exInfo.setDate(exRates.getDate());
		Rates rates = exRates.getRates();
		exInfo.setCAD(rates.getCAD());
		exInfo.setHKD(rates.getHKD());
		exInfo.setISK(rates.getISK());
		exInfo.setPHP(rates.getPHP());
		exInfo.setDKK(rates.getDKK());
		exInfo.setHUF(rates.getHUF());
		exInfo.setHUF(rates.getHUF());
		exInfo.setCZK(rates.getCZK());
		exInfo.setRON(rates.getRON());
		exInfo.setSEK(rates.getSEK());
		exInfo.setIDR(rates.getIDR());
		exInfo.setINR(rates.getINR());
		exInfo.setBRL(rates.getBRL());
		exInfo.setRUB(rates.getRUB());
		exInfo.setHRK(rates.getHRK());
		exInfo.setJPY(rates.getJPY());
		exInfo.setTHB(rates.getTHB());
		exInfo.setCHF(rates.getCHF());
		exInfo.setSGD(rates.getSGD());
		exInfo.setPLN(rates.getPLN());
		exInfo.setBGN(rates.getBGN());
		exInfo.setTRY(rates.getTRY());
		exInfo.setCNY(rates.getCNY());
		exInfo.setNOK(rates.getNOK());
		exInfo.setNZD(rates.getNZD());
		exInfo.setZAR(rates.getZAR());
		exInfo.setUSD(rates.getUSD());
		exInfo.setMXN(rates.getMXN());
		exInfo.setILS(rates.getILS());
		exInfo.setGBP(rates.getGBP());
		exInfo.setKRW(rates.getKRW());
		exInfo.setMYR(rates.getMYR());
		return exInfo;
	}
	
}
