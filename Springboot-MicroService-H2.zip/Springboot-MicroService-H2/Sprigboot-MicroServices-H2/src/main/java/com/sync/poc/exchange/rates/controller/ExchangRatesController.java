package com.sync.poc.exchange.rates.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.sync.poc.exchange.rates.domain.ExchangeRatesInfo;
import com.sync.poc.exchange.rates.exception.ResourceNotFoundException;
import com.sync.poc.exchange.rates.model.ExchangeRates;
import com.sync.poc.exchange.rates.service.ExchangeRatesService;
import com.sync.poc.exchange.rates.transform.ExchangeRatesTransform;

@RestController
@RequestMapping("/api/v1")
public class ExchangRatesController {

	@Autowired
	ExchangeRatesService service;

	@PostMapping("/exchangerate/{date}")
	public ExchangeRatesInfo createExchangRates(@PathVariable(value = "date") String date) {

		Map<String, String> params = new HashMap<String, String>();
		params.put("date", date);
		ResponseEntity<ExchangeRates> responseEntity = new RestTemplate()
				.getForEntity("https://api.exchangeratesapi.io/{date}", ExchangeRates.class, params);

		ExchangeRates exRates = responseEntity.getBody();
		ExchangeRatesInfo exchangeRatesInfo = ExchangeRatesTransform.getExchangeRatesInfo(exRates);
		return service.createExchangeRates(exchangeRatesInfo);
	}

	@GetMapping("/exchangerate/{date}")
	public ResponseEntity<ExchangeRatesInfo> getExchangRates(@PathVariable(value = "date") String date) throws ResourceNotFoundException {

		ExchangeRatesInfo excinfo = service.getExchangeRates(date);
		if (excinfo == null) {
			throw new ResourceNotFoundException("Exchang Rates Not found for this date :" + date);
		}
		return new ResponseEntity(excinfo, HttpStatus.OK);
	}

}
