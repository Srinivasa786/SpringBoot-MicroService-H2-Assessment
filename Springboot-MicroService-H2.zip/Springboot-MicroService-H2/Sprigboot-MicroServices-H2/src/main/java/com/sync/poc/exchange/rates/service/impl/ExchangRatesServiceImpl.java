package com.sync.poc.exchange.rates.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sync.poc.exchange.rates.domain.ExchangeRatesInfo;
import com.sync.poc.exchange.rates.repository.ExchangeRatesRepository;
import com.sync.poc.exchange.rates.service.ExchangeRatesService;

@Service
public class ExchangRatesServiceImpl implements ExchangeRatesService{

	@Autowired
	ExchangeRatesRepository exchangeRatesRepository;
	 
	@SuppressWarnings("unused")
	@Override
	public ExchangeRatesInfo createExchangeRates(ExchangeRatesInfo exchangeRates) {
		ExchangeRatesInfo exinfo = null;
		exinfo = exchangeRatesRepository.findByDate(exchangeRates.getDate());
		if (exchangeRates == null) {
			return exchangeRatesRepository.save(exchangeRates);
		} else {
			return exinfo;
		}
	}

	
	@Override
	public ExchangeRatesInfo getExchangeRates(String  date) {
		return exchangeRatesRepository.findByDate(date);
	}

}
