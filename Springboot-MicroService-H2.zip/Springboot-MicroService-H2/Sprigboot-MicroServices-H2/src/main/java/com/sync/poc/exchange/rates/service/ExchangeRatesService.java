package com.sync.poc.exchange.rates.service;

import com.sync.poc.exchange.rates.domain.ExchangeRatesInfo;


public interface ExchangeRatesService {
	public ExchangeRatesInfo createExchangeRates(ExchangeRatesInfo exchangeRates);
	public ExchangeRatesInfo getExchangeRates(String date);
}
