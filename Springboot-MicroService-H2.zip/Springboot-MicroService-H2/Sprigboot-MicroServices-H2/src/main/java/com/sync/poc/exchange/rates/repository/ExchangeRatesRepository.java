package com.sync.poc.exchange.rates.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sync.poc.exchange.rates.domain.ExchangeRatesInfo;

@Repository
public interface ExchangeRatesRepository extends JpaRepository<ExchangeRatesInfo, Long> {
	ExchangeRatesInfo findByDate(String date);
}