package com.sync.poc.exchange.rates.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ExchangeRates implements Serializable {
	private static final long serialVersionUID = -7473048265997705547L;
				@JsonProperty("base")
			    private String base;
	            @JsonProperty("date")
			    private String date;
	            @JsonProperty("rates")
			    private Rates rates;
				public String getBase() {
					return base;
				}
				public void setBase(String base) {
					this.base = base;
				}
				public String getDate() {
					return date;
				}
				public void setDate(String date) {
					this.date = date;
				}
				public Rates getRates() {
					return rates;
				}
				public void setRates(Rates rates) {
					this.rates = rates;
				}
			    
				}
