package com.sync.poc.exchange.rates.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EXCHANGE_RATES")
public class ExchangeRatesInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "EXCHANGE_RATE_ID")
	private Long id;
	
	@Column(name = "BASE_CURRENCY")
	private String base;
	
	@Column(name = "DATE")
	private String date;

	@Column(name = "CAD")
	private double CAD;
	
	@Column(name = "HKD")
	private double HKD;
	
	@Column(name = "ISK")
	private double ISK;
    
	@Column(name = "PHP")
	private double PHP;
    
	@Column(name = "DKK")
	private double DKK;
    
	@Column(name = "HUF")
	private double HUF;
    
	@Column(name = "CZK")
	private double CZK;
    
	@Column(name = "AUD")
	private double AUD;
    
	@Column(name = "RON")
	private double RON;
    
	@Column(name = "SEK")
	private double SEK;
    
	@Column(name = "IDR")
	private double IDR;
	
	@Column(name = "INR")
	private double INR;
	
	@Column(name = "BRL")
	private double BRL;
    
	@Column(name = "RUB")
	private double RUB;
    
	@Column(name = "HRK")
	private double HRK;
    
	@Column(name = "JPY")
	private double JPY;
	
	@Column(name = "THB")
	private double THB;
    
	@Column(name = "CHF")
	private double CHF;
    
	@Column(name = "SGD")
	private double SGD;
    
	@Column(name = "PLN")
	private double PLN;
    
	@Column(name = "BGN")
	private double BGN;
    
	@Column(name = "TRY")
	private double TRY;
    
	@Column(name = "CNY")
	private double CNY;
    
	@Column(name = "NOK")
	private double NOK;
    
	@Column(name = "NZD")
	private double NZD;
    
	@Column(name = "ZAR")
	private double ZAR;
    
	@Column(name = "USD")
	private double USD;
    
	@Column(name = "MXN")
	private double MXN;
    
	@Column(name = "ILS")
	private double ILS;
    
	@Column(name = "GBP")
	private double GBP;
    
	@Column(name = "KRW")
	private double KRW;
    
	@Column(name = "MYR")
	private double MYR;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getBase() {
		return base;
	}

	public void setBase(String base) {
		this.base = base;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public double getCAD() {
		return CAD;
	}

	public void setCAD(double cAD) {
		CAD = cAD;
	}

	public double getHKD() {
		return HKD;
	}

	public void setHKD(double hKD) {
		HKD = hKD;
	}

	public double getISK() {
		return ISK;
	}

	public void setISK(double iSK) {
		ISK = iSK;
	}

	public double getPHP() {
		return PHP;
	}

	public void setPHP(double pHP) {
		PHP = pHP;
	}

	public double getDKK() {
		return DKK;
	}

	public void setDKK(double dKK) {
		DKK = dKK;
	}

	public double getHUF() {
		return HUF;
	}

	public void setHUF(double hUF) {
		HUF = hUF;
	}

	public double getCZK() {
		return CZK;
	}

	public void setCZK(double cZK) {
		CZK = cZK;
	}

	public double getAUD() {
		return AUD;
	}

	public void setAUD(double aUD) {
		AUD = aUD;
	}

	public double getRON() {
		return RON;
	}

	public void setRON(double rON) {
		RON = rON;
	}

	public double getSEK() {
		return SEK;
	}

	public void setSEK(double sEK) {
		SEK = sEK;
	}

	public double getIDR() {
		return IDR;
	}

	public void setIDR(double iDR) {
		IDR = iDR;
	}

	public double getINR() {
		return INR;
	}

	public void setINR(double iNR) {
		INR = iNR;
	}

	public double getBRL() {
		return BRL;
	}

	public void setBRL(double bRL) {
		BRL = bRL;
	}

	public double getRUB() {
		return RUB;
	}

	public void setRUB(double rUB) {
		RUB = rUB;
	}

	public double getHRK() {
		return HRK;
	}

	public void setHRK(double hRK) {
		HRK = hRK;
	}

	public double getJPY() {
		return JPY;
	}

	public void setJPY(double jPY) {
		JPY = jPY;
	}

	public double getTHB() {
		return THB;
	}

	public void setTHB(double tHB) {
		THB = tHB;
	}

	public double getCHF() {
		return CHF;
	}

	public void setCHF(double cHF) {
		CHF = cHF;
	}

	public double getSGD() {
		return SGD;
	}

	public void setSGD(double sGD) {
		SGD = sGD;
	}

	public double getPLN() {
		return PLN;
	}

	public void setPLN(double pLN) {
		PLN = pLN;
	}

	public double getBGN() {
		return BGN;
	}

	public void setBGN(double bGN) {
		BGN = bGN;
	}

	public double getTRY() {
		return TRY;
	}

	public void setTRY(double tRY) {
		TRY = tRY;
	}

	public double getCNY() {
		return CNY;
	}

	public void setCNY(double cNY) {
		CNY = cNY;
	}

	public double getNOK() {
		return NOK;
	}

	public void setNOK(double nOK) {
		NOK = nOK;
	}

	public double getNZD() {
		return NZD;
	}

	public void setNZD(double nZD) {
		NZD = nZD;
	}

	public double getZAR() {
		return ZAR;
	}

	public void setZAR(double zAR) {
		ZAR = zAR;
	}

	public double getUSD() {
		return USD;
	}

	public void setUSD(double uSD) {
		USD = uSD;
	}

	public double getMXN() {
		return MXN;
	}

	public void setMXN(double mXN) {
		MXN = mXN;
	}

	public double getILS() {
		return ILS;
	}

	public void setILS(double iLS) {
		ILS = iLS;
	}

	public double getGBP() {
		return GBP;
	}

	public void setGBP(double gBP) {
		GBP = gBP;
	}

	public double getKRW() {
		return KRW;
	}

	public void setKRW(double kRW) {
		KRW = kRW;
	}

	public double getMYR() {
		return MYR;
	}

	public void setMYR(double mYR) {
		MYR = mYR;
	}

}
